module.exports = {
    'connection': {
        'host': 'localhost',
        'user': 'root',
        'password': 'password'
    },
	'database': 'employeedb',
    'users_table': 'users'
};